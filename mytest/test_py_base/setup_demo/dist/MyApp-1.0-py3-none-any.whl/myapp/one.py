#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""one"""
# @Time    : 2019/10/25 20:26
# @Author  : Wind
# @Des     : 
# @Software: PyCharm


def hello():
    print('Hello, welcome to setuptools!')